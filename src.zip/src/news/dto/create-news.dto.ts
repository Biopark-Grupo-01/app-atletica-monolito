export class CreateNewsDto {
  image: string;
  title: string;
  date: Date;
  location: string;
  description: string;
}
